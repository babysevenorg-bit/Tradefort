import { NextResponse } from "next/server";
import { UnauthorizedError } from "./auth";

export function ok(data: unknown, init?: ResponseInit) {
  return NextResponse.json(data, init);
}

export function fail(message: string, status = 400) {
  return NextResponse.json({ error: message }, { status });
}

export async function handle<T>(fn: () => Promise<T>): Promise<Response> {
  try {
    const data = await fn();
    return ok(data);
  } catch (e) {
    if (e instanceof UnauthorizedError) return fail("Not signed in", 401);
    const message = e instanceof Error ? e.message : "Unexpected error";
    console.error("[api]", message);
    return fail(message, 400);
  }
}

export const n = (v: unknown) => Number(v ?? 0);
